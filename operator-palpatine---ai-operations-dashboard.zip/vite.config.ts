import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  // Configure the development server
  server: {
    port: 8000,
    proxy: {
      // Proxy API requests to the FastAPI backend during development
      '/invoke': {
        target: 'http://localhost:8001', // Your FastAPI server address
        changeOrigin: true, // Needed for virtual hosted sites
        secure: false,      
      },
      // Proxy streaming requests to the FastAPI backend
      '/stream': {
        target: 'http://localhost:8001', // Your FastAPI server address for streaming
        changeOrigin: true,
        secure: false,
      },
    },
  },
  plugins: [react()],
  // Preserve existing configuration for reverse proxy and environment variables
  base: '/proxy/8000/',
  define: {
    'process.env': {}
  }
})