import React from 'react';
import { DashboardCard } from './DashboardCard';

export const DataQualityCard: React.FC = () => {
  return (
    <DashboardCard title="Data Quality">
      <div className="text-center py-4">
        <p className="text-6xl font-bold text-sw-accent-green">99.74<span className="text-4xl">%</span></p>
      </div>
    </DashboardCard>
  );
};