import React, { useState } from 'react';
import { INCIDENTS } from '../constants';
import { Incident } from '../types';
import { geminiService } from '../services/geminiService';

const IncidentItem: React.FC<{ incident: Incident }> = ({ incident }) => {
  const [isResolving, setIsResolving] = useState(false);
  const [resolution, setResolution] = useState<string | null>(null);

  const handleResolve = async () => {
    setIsResolving(true);
    setResolution(null); // Clear previous resolution
    try {
      const prompt = `Provide a concise, step-by-step resolution plan for the following network incident: "${incident.title}". Additional context: ${incident.description}`;
      // Updated to call the simplified, mock-only service method
      const result = await geminiService.runQuery(prompt);
      setResolution(result);
    } catch (error) {
      console.error('Failed to resolve incident:', error);
      const errorMessage = "The Force is disturbed. Could not retrieve a resolution plan.";
      setResolution(errorMessage);
    } finally {
      setIsResolving(false);
    }
  };

  return (
    <div className="bg-sw-dark-panel border border-sw-border rounded-lg p-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex-grow">
          <h3 className="font-bold text-sw-text-primary text-md">{incident.title}</h3>
          <p className="text-sm text-sw-text-secondary mt-1">{incident.description}</p>
        </div>
        <button
          onClick={handleResolve}
          disabled={isResolving}
          className="w-full sm:w-auto flex-shrink-0 bg-sw-accent-red hover:brightness-110 text-white font-bold py-2 px-6 rounded-md transition-all duration-200 flex items-center justify-center disabled:bg-opacity-50 disabled:cursor-not-allowed"
        >
          {isResolving ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Resolving...
            </>
          ) : 'AI Resolve'}
        </button>
      </div>
      {resolution && (
        <div className="mt-4 p-3 bg-sw-dark rounded-md border border-sw-border animate-fade-in">
          <p className="text-sm font-mono text-sw-text-secondary whitespace-pre-wrap"><span className="font-bold text-sw-text-primary">AI Resolution Plan:</span> {resolution}</p>
        </div>
      )}
    </div>
  );
};

export const IncidentsCard: React.FC = () => {
  return (
    <div className="space-y-4">
      {INCIDENTS.map(incident => (
        <IncidentItem key={incident.id} incident={incident} />
      ))}
    </div>
  );
};