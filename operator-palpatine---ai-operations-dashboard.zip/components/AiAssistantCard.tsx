import React, { useState, useEffect, useRef } from 'react';
import { DashboardCard } from './DashboardCard';
import { geminiService } from '../services/geminiService';
import { ChatMessage } from '../types';
import { TypingIndicator } from './TypingIndicator';

const agentName = 'Palpatine (Emperor)';

export const AiAssistantCard: React.FC = () => {
    const [input, setInput] = useState('');
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
        { author: agentName, content: 'Greetings, Operator. How may I assist you today?' }
    ]);
    const [isLoading, setIsLoading] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [chatHistory, isLoading]);

    const handleSendMessage = async () => {
        if (!input.trim() || isLoading) return;
        
        const userMessage: ChatMessage = { author: 'You', content: input };
        const currentInput = input;
        
        setChatHistory(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            let firstChunk = true;
            for await (const chunk of geminiService.runQueryStream(currentInput)) {
                setChatHistory(prev => {
                    const newHistory = [...prev];
                    const lastMessage = newHistory[newHistory.length - 1];

                    // If it's the first chunk from this agent, add a new message
                    if (firstChunk || !lastMessage || lastMessage.author !== chunk.agent || lastMessage.author === 'You') {
                         newHistory.push({ author: chunk.agent, content: chunk.response });
                    } else {
                         // Otherwise, append the content
                        lastMessage.content += chunk.response;
                    }
                    firstChunk = false;
                    return newHistory;
                });
            }
        } catch (error) {
            console.error("Failed to get AI response:", error);
            setChatHistory(prev => [...prev, { 
                author: 'System', 
                content: "I am unable to process your request at this time." 
            }]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <DashboardCard title="Vibe Operators AI Assistant" className="flex flex-col" titleClassName="text-sw-text-primary font-bold">
            <div className="flex border-b border-sw-border">
                <button 
                    className={`px-4 py-2 text-sm font-medium -mb-px border-b-2 border-sw-accent-blue text-sw-accent-blue cursor-default`}
                    aria-current="page"
                >
                    {agentName}
                </button>
            </div>
            <div className="flex-grow h-[42rem] bg-sw-dark p-3 my-4 rounded-md overflow-y-auto font-mono text-sm space-y-2">
                {chatHistory.map((msg, index) => (
                     <p key={index} className={msg.author === 'You' ? 'text-sw-text-primary' : 'text-sw-accent-green'}>
                        <span className="font-bold">{msg.author}: </span>
                        {msg.content}
                     </p>
                ))}
                {isLoading && <TypingIndicator agentName={agentName.split(' ')[0]} />}
                <div ref={chatEndRef} />
            </div>
            <div className="mt-auto">
                <input 
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder={isLoading ? 'Awaiting response...' : `Talk with ${agentName.split(' ')[0]}...`}
                    disabled={isLoading}
                    className="w-full p-2 bg-sw-dark border border-sw-border rounded-md focus:outline-none focus:ring-2 focus:ring-sw-accent-blue focus:border-sw-accent-blue placeholder-sw-text-secondary disabled:bg-opacity-50 disabled:cursor-not-allowed"
                />
                <p className="text-xs text-sw-text-secondary mt-2">GDPR and personal data are strictly forbidden. You remain responsible.</p>
            </div>
        </DashboardCard>
    )
}