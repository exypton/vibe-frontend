import React from 'react';

export const TypingIndicator: React.FC<{ agentName: string }> = ({ agentName }) => {
    return (
        <p className="text-sw-accent-green animate-fade-in">
            <span className="font-bold">{agentName}: </span>
            <span className="inline-flex items-center align-middle">
                <span className="w-2 h-2 bg-current rounded-full animate-blink" />
                <span className="w-2 h-2 bg-current rounded-full animate-blink ml-1" style={{ animationDelay: '0.2s' }} />
                <span className="w-2 h-2 bg-current rounded-full animate-blink ml-1" style={{ animationDelay: '0.4s' }} />
            </span>
        </p>
    );
};
