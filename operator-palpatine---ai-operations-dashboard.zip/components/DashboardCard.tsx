import React from 'react';

interface DashboardCardProps {
  title: string;
  children: React.ReactNode;
  className?: string;
  titleClassName?: string;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ title, children, className, titleClassName }) => {
  return (
    <div className={`bg-sw-dark-panel border border-sw-border rounded-lg text-sw-text-primary ${className}`}>
      <h2 className={`text-base font-semibold text-sw-text-secondary px-4 py-2 border-b border-sw-border ${titleClassName}`}>
        {title}
      </h2>
      <div className="p-4">
        {children}
      </div>
    </div>
  );
};