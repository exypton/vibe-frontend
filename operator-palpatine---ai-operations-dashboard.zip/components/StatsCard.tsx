import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DashboardCard } from './DashboardCard';
import { STATS_CHART_DATA } from '../constants';
import { MessageIcon } from './icons/MessageIcon';
import { LeadsIcon } from './icons/LeadsIcon';
import { AchievementsIcon } from './icons/AchievementsIcon';

const StatItem: React.FC<{ value: string; label: string; subtext: string; children: React.ReactNode }> = ({ value, label, subtext, children }) => (
    <div className="flex items-center space-x-4">
        <div className="bg-sw-dark-panel p-3 rounded-lg border border-sw-border">
            {children}
        </div>
        <div>
            <p className="text-sw-text-secondary text-xs font-bold uppercase tracking-wider">{label}</p>
            <p className="text-2xl font-bold text-sw-text-primary">{value}</p>
            <p className="text-xs text-sw-text-secondary">{subtext}</p>
        </div>
    </div>
);


const GoalCircle: React.FC<{ percentage: number }> = ({ percentage }) => {
    const radius = 25;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div className="relative w-16 h-16 flex items-center justify-center">
            <svg className="w-full h-full" viewBox="0 0 60 60">
                <circle cx="30" cy="30" r={radius} className="text-sw-border" strokeWidth="6" stroke="currentColor" fill="transparent" />
                <circle
                    cx="30"
                    cy="30"
                    r={radius}
                    className="text-sw-accent-blue"
                    strokeWidth="6"
                    stroke="currentColor"
                    fill="transparent"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    transform="rotate(-90 30 30)"
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dashoffset 0.5s ease-out' }}
                />
            </svg>
             <div className="absolute flex flex-col items-center justify-center">
                <span className="text-xs font-bold text-sw-text-secondary">Goal</span>
                <span className="text-base font-bold text-sw-text-primary">{percentage}%</span>
            </div>
        </div>
    );
};


export const StatsCard: React.FC = () => {
    return (
        <DashboardCard title="Stats">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center mb-6">
                <StatItem value="85" label="New Messages" subtext="78% Response Rate">
                   <MessageIcon className="w-6 h-6 text-sw-text-secondary"/>
                </StatItem>
                 <StatItem value="21" label="New Leads" subtext="40% Daily Goal">
                   <LeadsIcon className="w-6 h-6 text-sw-text-secondary"/>
                </StatItem>
                <div className="flex justify-center">
                     <GoalCircle percentage={67} />
                </div>
                 <StatItem value="95" label="Achievements" subtext="89% Response Rate">
                   <AchievementsIcon className="w-6 h-6 text-sw-text-secondary"/>
                </StatItem>
            </div>
            <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={STATS_CHART_DATA} margin={{ top: 5, right: 20, left: -15, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#30363d" />
                        <YAxis stroke="#7d8590" fontSize={12} tickLine={false} axisLine={false} />
                        <XAxis dataKey="name" stroke="#7d8590" fontSize={12} tickLine={false} axisLine={false} dy={5} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#161b22', border: '1px solid #30363d', borderRadius: '0.5rem' }} 
                            labelStyle={{color: '#e6edf3'}} 
                            itemStyle={{color: '#a371f7'}} 
                        />
                        <Line type="monotone" dataKey="val" stroke="#a371f7" strokeWidth={2} dot={{ r: 4, fill: '#a371f7' }} activeDot={{ r: 6 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </DashboardCard>
    );
};