import React from 'react';
import { DashboardCard } from './DashboardCard';
import { CheckIcon } from './icons/CheckIcon';
import { STATUS_ITEMS } from '../constants';
import { StatusItem } from '../types';

const StatusItemView: React.FC<{ item: StatusItem }> = ({ item }) => {
    return (
        <div className="flex justify-between items-center bg-sw-dark p-3 rounded-md border border-sw-border">
            <span className="font-medium text-sw-text-primary">{item.description}</span>
            {item.completed && <CheckIcon className="w-5 h-5 text-sw-accent-green" />}
        </div>
    )
}

export const WhatIsHappeningCard: React.FC = () => {
    return (
        <DashboardCard title="What's happening...">
            <div className="space-y-3">
                {STATUS_ITEMS.map(item => <StatusItemView key={item.id} item={item} />)}
            </div>
        </DashboardCard>
    )
}