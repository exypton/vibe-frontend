import React from 'react';
import { DashboardCard } from './DashboardCard';

export const IncidentCountCard: React.FC = () => {
  return (
    <DashboardCard title="Incident Count">
      <div className="text-center py-4">
        <p className="text-7xl font-bold text-sw-accent-red">13</p>
      </div>
    </DashboardCard>
  );
};