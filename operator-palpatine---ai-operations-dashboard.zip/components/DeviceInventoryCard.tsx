import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { DashboardCard } from './DashboardCard';
import { INVENTORY_PIE_DATA } from '../constants';

const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-sw-dark-panel p-2 border border-sw-border rounded-md">
          <p className="label text-sw-text-primary">{`${payload[0].name} : ${payload[0].value}`}</p>
        </div>
      );
    }
  
    return null;
  };

export const DeviceInventoryCard: React.FC = () => {
  return (
    <DashboardCard title="Device Inventory">
      <div style={{ width: '100%', height: 220 }} className="-ml-4">
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={INVENTORY_PIE_DATA}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              nameKey="name"
            >
              {INVENTORY_PIE_DATA.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} stroke={entry.fill} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend iconSize={10} layout="vertical" verticalAlign="middle" align="right" />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </DashboardCard>
  );
};