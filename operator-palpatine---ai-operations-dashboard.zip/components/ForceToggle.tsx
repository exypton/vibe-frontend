
import React, { useState } from 'react';

export const ForceToggle: React.FC = () => {
  const [enabled, setEnabled] = useState(false);

  return (
    <div className="flex items-center justify-end">
        <div className="flex items-center space-x-3">
            <span id="force-toggle-label" className="font-semibold text-sw-text-primary">
                Use the Force (Auto-Fixing)
            </span>
            <button
                type="button"
                role="switch"
                aria-checked={enabled}
                aria-labelledby="force-toggle-label"
                onClick={() => setEnabled(!enabled)}
                className={`${
                    enabled ? 'bg-sw-accent-green' : 'bg-sw-border'
                } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-sw-accent-blue focus:ring-offset-2 focus:ring-offset-sw-dark`}
            >
                <span
                    aria-hidden="true"
                    className={`${
                        enabled ? 'translate-x-5' : 'translate-x-0'
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                />
            </button>
        </div>
    </div>
  );
};
