import React from 'react';
import { DashboardCard } from './DashboardCard';
import { AGENTS } from '../constants';
import { Agent } from '../types';

const AgentItem: React.FC<{ agent: Agent }> = ({ agent }) => (
    <div className="flex justify-between items-center bg-sw-dark p-3 rounded-md border border-sw-border">
        <span className="font-medium text-sw-text-primary">{`${agent.name} (${agent.role})`}</span>
        {agent.status === 'online' && (
            <div className="flex items-center space-x-2">
                 <span className="text-xs text-sw-accent-green">Online</span>
                 <div className="w-2 h-2 rounded-full bg-sw-accent-green animate-pulse"></div>
            </div>
        )}
         {agent.status === 'offline' && (
            <div className="flex items-center space-x-2">
                 <span className="text-xs text-sw-text-secondary">Offline</span>
                 <div className="w-2 h-2 rounded-full bg-sw-text-secondary"></div>
            </div>
        )}
    </div>
)

export const AgentStatusCard: React.FC = () => {
  return (
    <DashboardCard title="Agents Status">
      <div className="space-y-3">
        {AGENTS.map(agent => (
            <AgentItem key={agent.name} agent={agent}/>
        ))}
      </div>
    </DashboardCard>
  );
};