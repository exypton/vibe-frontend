import React from 'react';
import { AiAssistantCard } from './components/AiAssistantCard';
import { WhatIsHappeningCard } from './components/WhatIsHappeningCard';
import { StatsCard } from './components/StatsCard';
import { IncidentsCard } from './components/IncidentsCard';
import { DataQualityCard } from './components/DataQualityCard';
import { IncidentCountCard } from './components/IncidentCountCard';
import { AgentStatusCard } from './components/AgentStatusCard';
import { DeviceInventoryCard } from './components/DeviceInventoryCard';
import { ForceToggle } from './components/ForceToggle';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-sw-dark text-sw-text-primary p-4 lg:p-6 font-sans">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-sw-text-primary">Operator Palpatine</h1>
      </header>
      
      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-4 space-y-6">
          <StatsCard />
          <IncidentsCard />
        </div>

        {/* Middle Column */}
        <div className="lg:col-span-5 space-y-6">
          <AiAssistantCard />
        </div>

        {/* Right Column */}
        <div className="lg:col-span-3 space-y-6">
          <WhatIsHappeningCard />
          <DataQualityCard />
          <IncidentCountCard />
          <AgentStatusCard />
          <DeviceInventoryCard />
        </div>
      </main>

      <footer className="mt-6">
        <ForceToggle />
      </footer>
    </div>
  );
};

export default App;