

export interface Agent {
  name: string;
  role: string;
  status: 'online' | 'offline';
}

export interface Incident {
  id: string;
  title: string;
  description: string;
}

export interface Task {
    id:string;
    description: string;
}

export interface StatusItem {
    id: string;
    description: string;
    completed: boolean;
}

export interface ChatMessage {
    author: string;
    content: string;
}