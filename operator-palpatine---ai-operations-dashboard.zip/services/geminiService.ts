class ApiService {
  private invokeUrl: string;
  private streamUrl: string;

  constructor() {
    this.invokeUrl = '/invoke';
    this.streamUrl = '/stream';
    console.log("API service initialized. Endpoints: /invoke, /stream. Ready to connect to FastAPI backend.");
  }

  /**
   * Sends a prompt to the FastAPI backend and returns the model's complete response.
   * @param prompt The user's input prompt.
   * @returns A promise that resolves to a string with the AI's response.
   */
  public async runQuery(prompt: string): Promise<string> {
    try {
      const response = await fetch(this.invokeUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          "input": { "prompt": prompt },
          "config": {},
          "kwargs": {}
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const detail = errorData?.detail || `HTTP error! status: ${response.status}`;
        throw new Error(`The Force is disturbed. API request failed: ${detail}`);
      }

      const result = await response.json();
      const content = result?.output?.content;

      if (typeof content !== 'string') {
        throw new Error("Invalid response format from the AI. The 'output.content' field is missing or not a string.");
      }

      return content;

    } catch (error) {
      console.error("Failed to communicate with the supervisor model:", error);
      throw error;
    }
  }

  /**
   * Connects to the streaming endpoint and yields text chunks as they are received.
   * @param prompt The user's input prompt.
   * @returns An async generator that yields objects containing the agent and their response.
   */
  public async * runQueryStream(prompt: string): AsyncGenerator<{ agent: string, response: string }> {
    try {
      const response = await fetch(this.streamUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream',
        },
        body: JSON.stringify({
          "input": { "prompt": prompt },
          "config": {},
          "kwargs": {}
        }),
      });

      if (!response.ok || !response.body) {
        const errorData = await response.json().catch(() => null);
        const detail = errorData?.detail || `HTTP error! status: ${response.status}`;
        throw new Error(`The Force is disturbed. API stream request failed: ${detail}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      const processLine = function* (line: string): Generator<{agent: string, response: string}> {
        if (line.trim() === '') return;

        let jsonStr = line;
        if (jsonStr.startsWith('data: ')) {
          jsonStr = jsonStr.substring(6);
        }
        
        if (jsonStr.trim() === '') return;

        try {
          const json = JSON.parse(jsonStr);
          if (json.agent && typeof json.agent === 'string' && json.response && typeof json.response === 'string') {
            yield json;
          }
        } catch (e) {
          console.warn("Error parsing stream chunk, skipping:", jsonStr, e);
        }
      }

      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          if (buffer.trim()) {
            yield* processLine(buffer);
          }
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          yield* processLine(line);
        }
      }
    } catch (error) {
      console.error("Failed to stream from supervisor model:", error);
      throw error;
    }
  }
}

// The service is now a generic API service, but we keep the export name for minimal changes
export const geminiService = new ApiService();