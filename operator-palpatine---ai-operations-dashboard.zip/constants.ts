
import { Agent, Incident, Task, StatusItem } from './types';

export const AGENTS: Agent[] = [
  { name: 'Supervisor', role: 'Emperor', status: 'online' },
];

export const INCIDENTS: Incident[] = [
  { id: '10013', title: 'BGP Peering Flap #10013', description: 'Description of the problem...' },
  { id: '10014', title: 'High Error Rate #10014', description: 'Description of the problem...' },
  { id: '10015', title: 'Configuration Mismatch #10015', description: 'Description of the problem...' },
];

export const PENDING_TASKS: Task[] = [
    { id: '1', description: "Fix 'BGP Peering Flap #10013'" },
    { id: '2', description: "Fix 'Configuration Mismatch #10015'" },
];

export const STATUS_ITEMS: StatusItem[] = [
    { id: '1', description: 'Analyzing the issue...', completed: true },
    { id: '2', description: 'Checking the inventory...', completed: true },
]

export const STATS_CHART_DATA = [
  { name: 'T-6', val: 55 },
  { name: 'T-5', val: 110 },
  { name: 'T-4', val: 70 },
  { name: 'T-3', val: 130 },
  { name: 'T-2', val: 60 },
  { name: 'T-1', val: 95 },
  { name: 'Now', val: 40 },
  { name: 'F+1', val: 80 },
  { name: 'F+2', val: 120 },
];

export const INVENTORY_PIE_DATA = [
  { name: 'Routers', value: 45, fill: '#38bdf8' }, // light blue
  { name: 'Switches', value: 30, fill: '#f97316' }, // orange
  { name: 'Firewalls', value: 25, fill: '#14b8a6' }, // teal
];